#
# from odoo import models, fields, api
#
# """ inheritance in sale module"""
#
# class inhe(models.Model):
#     _inherit = 'product.template'
#
#
#     email = fields.Char()
#     mobile = fields.Integer()
#
