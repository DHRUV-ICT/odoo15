# -*- coding: utf-8 -*-

from . import student_models
from . import appointment_models
from . import proffessor_models
from . import tasks_models