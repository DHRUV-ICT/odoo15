from odoo import models, fields, api

class templates(models.Model):

    _name = 'templates.templates'
    _description='templates.templates'

