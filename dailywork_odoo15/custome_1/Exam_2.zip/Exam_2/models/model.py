from odoo import models, fields, api


class exam_2(models.Model):
    _name = 'exam.2'
    _description = 'exam_2'

    name = fields.Char()

